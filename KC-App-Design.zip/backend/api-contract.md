# 后端接口契约总览

> 本目录是 Electron 主进程与 PowerShell 脚本（用户持有维护）之间的对接依据。
> 脚本本体不存于本仓；用户更新脚本后重新发送，对应契约文档同步更新。

## 任务类型 × 脚本 × 契约状态

| 任务类型 | 脚本 | 契约文档 | 状态 |
|---|---|---|---|
| 导入图片 | `kc-import-images-ui.ps1` | [kc-import-contract.md](kc-import-contract.md) | ✅ 已就绪（2026-10-29 实测版拆解，用户三确认完成） |
| 新建 Topic / Map / Pub | `kc-create-objects-ui.ps1`（本仓 [scripts/](scripts/)） | [kc-create-contract.md](kc-create-contract.md) | ✅ 契约已写（2026-11-03 归档 3293 行原文）；4 个待确认项见契约第 9 节 |

**四类任务后端脚本已全部到齐**：P3 的四张类型卡片 = import（图片）+ create（Topic/Map/Pub）。

## 四脚本共性（待验证的假设）

导入图片脚本确认的架构约定，其余三个脚本到齐后逐一对照：

- Electron 主进程永远以 headless 方式调用（给全参数 → 不弹 Windows 窗体）
- stdout 逐行日志协议（`STEP N` / `[OK]` / `[X]` / `[预检]` / `[结果]`）→ 主进程解析器按行消费
- 两段式：先预检（不带 Commit，零写入）→ 用户确认 → 执行（带 Commit）
- 认证：账号密码参数传入；登录失败主动停止降级防锁号
- 目标平台 Windows（powershell.exe）；macOS 开发走 mock runner 回放录制日志

其余脚本如形态不同（比如 Node 脚本、exe），以实际脚本为准更新本节。
